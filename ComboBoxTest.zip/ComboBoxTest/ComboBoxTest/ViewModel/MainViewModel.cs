﻿using ComboBoxTest.Command;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.Devices.Scanners;
using Windows.UI.Xaml.Controls;

namespace ComboBoxTest.ViewModel
{
    class MainViewModel:BaseViewModel
    {
        //Test1: Does not work
        private List<object> list = new List<object>();
        public List<object> List
        {
            get { return list; }
            set { SetProperty(ref list, value); }
        }
        private int selectedIndex;
        public int SelectedIndex
        {
            get { return selectedIndex; }
            set { SetProperty(ref selectedIndex, value); }
        }
        private object selectedItem;
        public object SelectedItem
        {
            get { return selectedItem; }
            set { SetProperty(ref selectedItem, value); }
        }

        //Test2
        //private List<ComboBoxItem> list = new List<ComboBoxItem>();
        //public List<ComboBoxItem> List
        //{
        //    get { return list; }
        //    set { SetProperty(ref list, value); }
        //}

        //private ComboBoxItem selectedItem;
        //public ComboBoxItem SelectedItem
        //{
        //    get { return selectedItem; }
        //    set { SetProperty(ref selectedItem, value); }
        //}


        public MainViewModel()
        {
            //Test1: Does not work
            List = Enum.GetValues(typeof(ImageScannerScanSource)).Cast<object>().ToList();

            //Test2
            //var tempList = Enum.GetValues(typeof(ImageScannerScanSource)).Cast<ImageScannerScanSource>().ToList();
            //foreach (var item in tempList)
            //{
            //    List.Add(new ComboBoxItem() { Content = item });
            //}
        }

        public ICommand SelectedItemButtonCommand 
        {
            get 
            {
                return new CommandHandler(() => SelectedItemButtonCommandMethod());
            }
        }

        private void SelectedItemButtonCommandMethod()
        {
            //Test1: Does not work
            //if (List.Contains(ImageScannerScanSource.AutoConfigured))
            //{
            //    var index = List.IndexOf(ImageScannerScanSource.AutoConfigured);
            //    SelectedItem = new ComboBoxItem() { Content = List[index] };
            //}
            Debug.WriteLine(SelectedIndex);
            SelectedItem = List[SelectedIndex];
            //Test2
            //if((List.FindAll(w => (ImageScannerScanSource)w.Content == ImageScannerScanSource.AutoConfigured).Count > 0))
            //{
            //    var index = List.IndexOf(new ComboBoxItem { Content = ImageScannerScanSource.AutoConfigured });
            //    SelectedItem = List[index];
            //}
        }
    }
}
