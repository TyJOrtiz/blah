﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ComboBoxTest.Command
{
    class CommandHandler : ICommand
    {
        public event EventHandler CanExecuteChanged;

        private Action _action;
        private Action<object> actionWithParamaeter;

        public CommandHandler(Action action)
        {
            this._action = action;
        }

        public CommandHandler(Action<object> action)
        {
            actionWithParamaeter = action;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            if (_action != null)
                this._action();
            else if (actionWithParamaeter != null)
                this.actionWithParamaeter(parameter);
        }
    }
}
